class Player < ApplicationRecord
end